package mp1;

/*
 * This simple class aids in parsing a message into its separate fields
 */
public class ReceivedInputElements {
	String definition;
	String key;
	String key_value;
	String model;
	String reqNodeId;
	String reqNum;
	int reqNumEnd;
	String replyType;
	String timestamp;
	
	String identifier;
}
