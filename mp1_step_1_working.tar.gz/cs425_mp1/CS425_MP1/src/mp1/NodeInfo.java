package mp1;

public class NodeInfo {
	public String id = "";
	public String ip = "";
	public int port = -1;
	public double max_delay = -1;
}
